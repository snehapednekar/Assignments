﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpMS
{
    class Employee
    {
        protected int EmpNo;
        protected string EmpName;
        protected double Salary;
        protected double HRA;
        protected double TA;
        protected double DA;
        protected double PF;
        protected double TDS;
        public double NetSalary;
        public double GrossSalary;

        public void SetEmpNo(int EmpNo)
        {
            this.EmpNo = EmpNo;
        }
        public void SetEmpName(string EmpName)
        {
            this.EmpName = EmpName;
        }
        public void SetSalary(double Salary)
        {
            this.Salary = Salary;
        }

        public int GetEmpNo()
        {
            return EmpNo;
        }
        public string GetEmpName()
        {
            return EmpName;
        }
        public double GetSalary()
        {
            return Salary;
        }

        public Employee()
        {
            int EmpNo;
            string EmpName;
            double Salary;
            double HRA;
            double TA;
            double DA;
            double GrossSalary;
            double PF;
            double TDS;
            double NetSalary;

            Console.Write("\n\nInsert the information of Employee\n");

            Console.Write("\n\nEnter Employee No: ");
            EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Employee Name: ");
            EmpName = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Enter Employee Salary: ");
            Salary = Convert.ToDouble(Console.ReadLine());



            
            if (Salary < 5000)
            {

                HRA = (Salary * 10) / 100;
                TA = (Salary * 5) / 100;
                DA = (Salary * 15) / 100;
                GrossSalary = (Salary + HRA + TA + DA);
                Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);
                
            }
            else if ((Salary > 5000) && (Salary < 10000))
            {

                HRA = (Salary * 15) / 100;
                TA = (Salary * 10) / 100;
                DA = (Salary * 20) / 100;
                GrossSalary = (Salary + HRA + TA + DA);
                Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

            }
            else if ((Salary > 10000) && (Salary < 15000))
            {

                HRA = (Salary * 20) / 100;
                TA = (Salary * 15) / 100;
                DA = (Salary * 25) / 100;
                GrossSalary = (Salary + HRA + TA + DA);
                Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

            }
            else if ((Salary > 15000) && (Salary < 20000))
            {

                HRA = (Salary * 25) / 100;
                TA = (Salary * 20) / 100;
                DA = (Salary * 30) / 100;
                GrossSalary = (Salary + HRA + TA + DA);
                Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

            }
            else
            {
                HRA = (Salary * 30) / 100;
                TA = (Salary * 25) / 100;
                DA = (Salary * 35) / 100;
                GrossSalary = (Salary + HRA + TA + DA);
                Console.Write("Gross Salary :{0}\n ", +GrossSalary);

            }
            

      
         
            }
         public virtual void CalculateSalary()
              {
            double PF;
            double TDS;
            double NetSalary;
           
            PF = (GrossSalary * 10) / 100;
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);
            Console.Write(" Net Salary :{0}\n ", +NetSalary);

        }
              
}
            
       
       

      


        class Manager : Employee
        {


            public Manager()
            {
                double Salary;
                Console.Write("\n Enter Manager's Salary: ");
                Salary = Convert.ToDouble(Console.ReadLine());

                double PetrolAllowance = (Salary * 8) / 100;
                double FoodAllowance = (Salary * 13) / 100;
                double OtherAllowance = (Salary * 3) / 100;

                double GrossSalary = (PetrolAllowance + FoodAllowance + OtherAllowance);
                Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);
            }
            public override void CalculateSalary()
            {
                NetSalary = GrossSalary - (PF + TDS);
                Console.WriteLine(NetSalary);
                Console.ReadKey();
            }


        }

        class MarketingExecutive : Manager
        {
            

            public 	MarketingExecutive()
            {
                double Salary;
                Console.Write("\n Enter Marketing Executives Salary: ");
                Salary = Convert.ToDouble(Console.ReadLine());

                double KilometerTravaled = 60;
                double TourAllowance = 5*60;
                double TelephoneAllowance = 1000;

                double GrossSalary = (KilometerTravaled + TourAllowance + TelephoneAllowance);
                Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);
            }
            public override void CalculateSalary()
            {
                NetSalary = GrossSalary - (PF + TDS);
                Console.WriteLine(NetSalary);
                Console.ReadKey();
            }
             
            

        }

        class Program
        {
            static void Main(string[] args)
            {

              
             
                MarketingExecutive Me = new MarketingExecutive();
                
                Console.ReadKey();
                



            }

        }
 }   



