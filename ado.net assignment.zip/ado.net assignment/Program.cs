﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection sqlConnection;
            string connectionString = @"Data Source=DESKTOP-A07PO4O;Initial Catalog=EmpDB;Integrated Security=True";
            try

            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                Console.WriteLine("Connection Established Successfully");
                string ans;
                do
                { 
                Console.WriteLine("Select the operation to be performed:\n1.Create\n2.Retrive\n3.Update\n4.Delete");
                Console.WriteLine("\nEnter your Choice:");
                int ch=int.Parse(Console.ReadLine());
                switch (ch)
                { 
                case 1:
                //crud
               //insert data
                Console.WriteLine("Enter Employee Id: ");
                int EmpId = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Employee's Name: ");
                string  FirstName = Console.ReadLine();
                Console.WriteLine("Enter Employee Salary: ");
                int Salary = int.Parse(Console.ReadLine());

                string insertQuery = "Insert into Employee(EmpId, FirstName, Salary) values (" + EmpId + " ,' " + FirstName + " ', " + Salary + ")";
                SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnection);
                insertCommand.ExecuteNonQuery();
                Console.WriteLine("Data inserted into table\n");
                break;
                 case 2:
                //retrive

                string displayQuery= "select * from Employee";
                SqlCommand displayCommand= new SqlCommand(displayQuery, sqlConnection);
                SqlDataReader dataReader= displayCommand.ExecuteReader();
                while(dataReader.Read())
                {
                    Console.WriteLine("EmpId: "+dataReader.GetValue(0).ToString());
                    Console.WriteLine("FirstName: "+dataReader.GetValue(1).ToString());
                    Console.WriteLine("Salary: "+dataReader.GetValue(2).ToString());
                
                }
                dataReader.Close();

                break;
                 case 3:
                //update

                int id;
                int sal;
                Console.WriteLine("\n Enter id to update: ");
                id=int.Parse(Console.ReadLine());
                Console.WriteLine("\n Enter the salary : ");
                sal=int.Parse(Console.ReadLine());
                 string updateQuery="Update Employee set Salary=" +sal+ "where EmpId="+id+" ";
                SqlCommand updateCommand=new SqlCommand(updateQuery, sqlConnection);
                updateCommand.ExecuteNonQuery();
                Console.WriteLine("Data updated");
                break;
                 case 4:
                //delete

                int d_id;
                Console.WriteLine("\n Enter id to be deleted: ");
                d_id=int.Parse(Console.ReadLine());
               string deleteQuery= "delete from Employee where  EmpId="+d_id;
                SqlCommand deleteCommand=new SqlCommand(deleteQuery,sqlConnection);
                deleteCommand.ExecuteNonQuery();
                Console.WriteLine("Deleted ");
                 break;
                
                        default:Console.WriteLine("Enter correct choice");
                        break;
                }
                    Console.WriteLine("do you want to continue");
                    ans=Console.ReadLine();

              }while(ans!="No");
                sqlConnection.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
           
            Console.ReadLine();
        }
    }
}
