﻿using System;

namespace bank
{

    class bank
    { 
        public delegate void delegateMethod(int x);

        

            private double balance = 1000;

            public double bal

            {

                get { return balance; }

                set { balance = value; }

            }
            public event delegateMethod underBalance;
            public event delegateMethod zeroBalance;

            public void Insufficiet(int withdraw)
            {
                  underBalance(withdraw);
            }
        public void DepositeMoney(int depo)
            {
                  zeroBalance(depo);
            }
        }

        class fuctions

        {

            bank b= new bank();

            string name;

            int account;

            double withdraw, depo, total;

            public void deposite()

            {

                Console.WriteLine("Enter Name of the depositor:");

                name = Console.ReadLine();

                Console.WriteLine("Enter 9 digit Account Number:");

                account = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Deposit Amount:");

                depo = Convert.ToDouble(Console.ReadLine());

                total = b.bal + depo;

                Console.WriteLine("——————————\n");

                Console.WriteLine("Name of the depositor: " +name);

                Console.WriteLine("Account Number: " +account);

                Console.WriteLine("Total Balance amount in the account: "+total);

            }

            public void fwithdraw()

            {

                Console.WriteLine("Enter the Name:");

                name = Console.ReadLine();

                Console.WriteLine("Enter Account Number: ");

                account = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Withdraw Amount:");

                withdraw = Convert.ToDouble(Console.ReadLine());

                if (withdraw <= b.bal && b.bal!=0)

                {

                    total = b.bal-withdraw;

                    Console.WriteLine("—————————\n");

                    Console.WriteLine("Account Name: " + name);

                    Console.WriteLine("Account Number: " + account);

                    Console.WriteLine("After Withdraw Amount balnace is : " + total);

                }
                else if(withdraw>b.bal && b.bal!=0)
                {
                    Console.WriteLine("Insufficient amount\n");
                    Console.WriteLine("Balance is "+b.bal);
                     }

                else

                    Console.WriteLine("\nzero balance");

            }

        }

        class Program

        {

            static void Main(string[] args)

            {

                char optn;

                do

                {

                    fuctions f = new fuctions();

                    int num;

                    Console.WriteLine("Please Select Any Function.");

                    Console.WriteLine("\nPress 1 for Deposit an Amount. \nPress 2 for Withdraw an Amount.") ;

                    num = Convert.ToInt32(Console.ReadLine());

                    switch (num)

                    {

                        case 1:

                            f.deposite();

                            break;

                        case 2:

                            f.fwithdraw();

                            break;

                        default:

                            Console.WriteLine("Invalid Selection!!!");

                            break;

                    }

                    Console.WriteLine("\nDo you want to continue this program ? (y / n)");

                    optn = Convert.ToChar(Console.ReadLine());

                } while (optn == 'y');

                Console.ReadKey();

            }

        }

    }


