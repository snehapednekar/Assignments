﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSAssignment
{
    class StudentsMarksAssignment
    {
        static void Main(string[] args)

    {
            int i = 0;
            int highestMarks = 0;
            
            int[] arr = new int[5];

            Console.WriteLine("Enter the marks of 5 students : ");
            for (i = 0; i < arr.Length; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            highestMarks = arr[0];
            
            for (i = 1; i < arr.Length; i++)
            {
               
                if (highestMarks < arr[i])
                    highestMarks = arr[i];
            }
            Console.WriteLine("Highest Marks obtained : " + highestMarks);
            Console.ReadKey();
        }
        
    }
    
}