﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book
{
	using System;

	struct book
	{
		public int bookId;
		public string title;
		public int price;
		public string bookType;

	}
	public class DetailsOfBook
	{
		public static void Main()
		{
			int NoOfbook = 1000;
			book[] books = new book[NoOfbook];
			int i, j, n = 2, k = 1;
			Console.Write("\n\nInsert the information of books\n");

			for (j = 0; j <= n; j++)
			{
				Console.WriteLine("Information of book {0} :", k);

				Console.Write("Enter ID of the book : ");
				books[j].bookId = Convert.ToInt32(Console.ReadLine());

				Console.Write("Enter the title: ");
				books[j].title = Console.ReadLine();

				Console.Write("Enter the price: ");
				books[j].price = Convert.ToInt32(Console.ReadLine());

				Console.Write("Enter the type of book: ");
				books[j].bookType = Console.ReadLine();
				k++;
				Console.WriteLine();
			}

			for (i = 0; i <= n; i++)
			{
				Console.WriteLine("{0}: ID = {1},  Title = {2}, Price={3}, Type={4}", i + 1, books[i].bookId, books[i].title, books[i].price, books[i].bookType);
				Console.WriteLine();
				Console.ReadKey();
			}

		}
	}
}
