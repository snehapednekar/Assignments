﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSAssignment
{
    class Circle
    {
         static void Main(String[] args)
        {

            double r, circumference,area;
            double PI = 3.14;
            Console.WriteLine("Enter the radius of the circle : ");
            r = Convert.ToDouble(Console.ReadLine());
            area = PI * r * r;
            Console.WriteLine("\nThe area of circle is {0} ", area);
            circumference = 2 * PI * r;
            Console.WriteLine("Circumference of Circle : {0}", circumference);
            Console.Read();
        }
    }
}
