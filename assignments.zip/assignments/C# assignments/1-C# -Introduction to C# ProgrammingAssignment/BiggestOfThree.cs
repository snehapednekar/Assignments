﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSAssignment
{
    class BiggestOfThree
    {
         static void Main(string[] args)
        {
            int n1, n2, n3;
            Console.WriteLine("Enter 1st number: ");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2st number: ");
            n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 3st number: ");
            n3 = Convert.ToInt32(Console.ReadLine());

            if(n1>n2)
            {
                if(n1>n3)
                {
                    Console.Write("1st number is greater");
                }
                else
                {
                    Console.Write("3st number is greater");
                }
            }
            else if(n2>n3)
                Console.Write("2nd number is greater");
            else
                Console.Write("3rd number is greater");
            Console.ReadKey();
        }
    }
    
}
