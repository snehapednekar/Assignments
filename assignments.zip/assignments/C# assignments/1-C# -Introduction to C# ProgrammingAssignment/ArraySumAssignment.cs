﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSAssignment
{
    class ArraySumAssignment
    {

    static int Addition(int[] arr)
    {
        int sum = 0;
           
            for (int i = 0; i < arr.Length; i++)
        {
            sum = sum + arr[i];
        }
        return sum;
    }

   
    public static void Main(String[] args)
    {
        int[] arr = { 8, 9, 2, 3 };
        int n = arr.Length;

        Console.Write("Sum of given array is " + Addition(arr));
            Console.ReadKey();

    }
}    
}


