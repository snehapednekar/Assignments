﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y, result,ch;
            

            Console.WriteLine("Enter 1 for addition: ");
            Console.WriteLine("Enter 2 for substraction: ");
            Console.WriteLine("Enter 3 for Multiplication: ");
            Console.WriteLine("Enter 4 for Division: ");
            ch = Convert.ToInt32(Console.ReadLine());
           
            switch (ch)
            {
                case 1:
                    {
                        Console.WriteLine("Enter two numbers: ");
                        x = Convert.ToInt32(Console.ReadLine());
                        y = Convert.ToInt32(Console.ReadLine());
                        result = x + y;
                        Console.WriteLine("Addition is :" + result);
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Enter two numbers: ");
                        x = Convert.ToInt32(Console.ReadLine());
                        y = Convert.ToInt32(Console.ReadLine());
                        result = x - y;
                        Console.WriteLine("Result is :" + result);
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("Enter two numbers: ");
                        x = Convert.ToInt32(Console.ReadLine());
                        y = Convert.ToInt32(Console.ReadLine());
                        result = x * y;
                        Console.WriteLine("Result is :" + result);
                        break;
                    }
                case 4:
                    {
                        Console.WriteLine("Enter two numbers: ");
                        x = Convert.ToInt32(Console.ReadLine());
                        y = Convert.ToInt32(Console.ReadLine());
                        result = x / y;
                        Console.WriteLine("Result is :" + result);
                        break;
                    }
            }
            Console.ReadKey();

        }
     
    }
    
}

