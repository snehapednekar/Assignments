﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LitwareLib
{

    class Employee
    {
        private int EmpNo;
        private string EmpName;
        private double Salary;
        private double HRA;
        private double TA;
        private double DA;
        private double PF;
        private double TDS;
        private double NetSalary;
        private double GrossSalary;

        public void setEmpNo(int EmpNo)
        {
            this.EmpNo = EmpNo;
        }
        public void setEmpName(string EmpName)
        {
            this.EmpName = EmpName;
        }
        public void setSalary(double Salary)
        {
            this.Salary = Salary;
        }

        public int getEmpNo()
        {
            return EmpNo;
        }
        public string getEmpName()
        {
            return EmpName;
        }
        public double getSalary()
        {
            return Salary;
        }


    }
    class Program
    {
        static void Main(string[] args)
        {

            int EmpNo;
            string EmpName;
            double Salary;
            double HRA;
            double TA;
            double DA;
            double GrossSalary;

            Employee[] employees = new Employee[10];
            Console.Write("\n\nInsert the information of Employee\n");
            for (int i = 0; i < 2; i++)
            {
                Console.Write("\n\nEnter Employee No: ");
                EmpNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name: ");
                EmpName = Console.ReadLine();
                Console.Write("Enter Employee Salary: ");
                Salary = Convert.ToDouble(Console.ReadLine());

                employees[i] = new Employee();
                employees[i].setEmpNo(EmpNo);
                employees[i].setEmpName(EmpName);
                employees[i].setSalary(Salary);

                if (Salary < 5000)
                {

                    HRA = (Salary * 10) / 100;
                    TA = (Salary * 5) / 100;
                    DA = (Salary * 15) / 100;
                    GrossSalary = (Salary + HRA + TA + DA);
                    Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);
                    //  CalculateSalary();
                }
                else if ((Salary > 5000) && (Salary < 10000))
                {

                    HRA = (Salary * 15) / 100;
                    TA = (Salary * 10) / 100;
                    DA = (Salary * 20) / 100;
                    GrossSalary = (Salary + HRA + TA + DA);
                    Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

                }
                else if ((Salary > 10000) && (Salary < 15000))
                {

                    HRA = (Salary * 20) / 100;
                    TA = (Salary * 15) / 100;
                    DA = (Salary * 25) / 100;
                    GrossSalary = (Salary + HRA + TA + DA);
                    Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

                }
                else if ((Salary > 15000) && (Salary < 20000))
                {

                    HRA = (Salary * 25) / 100;
                    TA = (Salary * 20) / 100;
                    DA = (Salary * 30) / 100;
                    GrossSalary = (Salary + HRA + TA + DA);
                    Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

                }
                else
                {
                    HRA = (Salary * 30) / 100;
                    TA = (Salary * 25) / 100;
                    DA = (Salary * 35) / 100;
                    GrossSalary = (Salary + HRA + TA + DA);
                    Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);


                }
                CalculateSalary();
                Console.WriteLine();


                void CalculateSalary()

                {
                    double PF;
                    double TDS;
                    double NetSalary;

                    PF = (GrossSalary * 10) / 100;
                    TDS = (GrossSalary * 18) / 100;
                    NetSalary = GrossSalary - (PF + TDS);

                    Console.Write(" PF :{0}\n ", +PF);
                    Console.Write(" TDS :{0}\n ", +TDS);
                    Console.Write(" Net Salary :{0}\n ", +NetSalary);
                    Console.ReadKey();

                }


            }



        }




    }
}



