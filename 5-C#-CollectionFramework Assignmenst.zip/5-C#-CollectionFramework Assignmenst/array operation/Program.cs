﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollArray
{
    class Program
    {
        static void Main(string[] args)

        {

            // Create an array and add 5 items to it
            Array stringArray = Array.CreateInstance(typeof(String), 5);
            stringArray.SetValue("Bhoomi", 0);
            stringArray.SetValue("Anushka", 1);
            stringArray.SetValue("Shahid", 2);
            stringArray.SetValue("Kriti", 3);
            stringArray.SetValue("Hritik", 4);

            Console.WriteLine("Original Array\n\n");

            foreach (string str in stringArray)
            {
                Console.WriteLine(str);
            }
            Console.WriteLine();
            Console.WriteLine("Sorted Array\n\n");

            Array.Sort(stringArray);
            foreach (string str in stringArray)
            {
                Console.WriteLine(str);

            }
           

            Console.WriteLine();
            Console.WriteLine("Reversed Array\n\n");
           
            Array.Reverse(stringArray);
           
            foreach (string str in stringArray)
            {
                Console.WriteLine(str);
            }
            Console.ReadKey();
        }
    }
}