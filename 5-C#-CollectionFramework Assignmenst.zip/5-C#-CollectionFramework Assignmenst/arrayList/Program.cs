﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace CollectionAssignment
{ 
   
    class Employee
    { 
         public int EmpId {get; set; }
         public string EmpName { get; set;}
         public double EmpSal { get; set;}

         public Employee(int eid, string ename, double esal)
        {
              this.EmpId =eid;
              this.EmpName =ename;
              this.EmpSal=esal;
        }
     }

internal class Program
    {
       static void Main(string[] args)
        {
            ArrayList e = new ArrayList();
            List<Employee> eg = new List<Employee>();
            Employee e1 = new Employee(1001, "Sam", 50042);
            Employee e2 = new Employee(1002, "Raj", 86230);
            Employee e3 = new Employee(1003,"Jay", 77520);
            e.Add(e1);
            e.Add(e2);
            e.Add(e3);
            Console.WriteLine("List of Employess:\n");
            foreach (Employee i in e)
            {
                Console.WriteLine(i.EmpId + " " + i.EmpName + " "+ i.EmpSal);
            }
            Console.ReadKey();
        }
     }

}
