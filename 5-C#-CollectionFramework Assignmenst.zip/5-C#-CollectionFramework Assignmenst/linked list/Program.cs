﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpCol
{
    class Program
    {
        static void Main(string[] args)
        {

   LinkedList<String> my_list = new LinkedList<String>();

                // Adding elements in the LinkedList
                // Using AddLast() method
                my_list.AddFirst("Ravi");
                my_list.AddLast("Amol");
                my_list.AddLast("Rohit");
                my_list.AddLast("Leena");
                my_list.AddFirst("Juhi");
                my_list.AddLast("Rahul");

                Console.WriteLine("Names of Employees:");
            

            // Accessing the elements of
            // LinkedList Using foreach loop
            foreach (string str in my_list)
                {
                    Console.WriteLine(str);
               
                }
            Console.WriteLine("\n\n Search for the employee name Raj:");
            if (my_list.Contains("Raj") == true)
            {
                Console.WriteLine("\n\n Employee Found...!!");
            }
            else
            {
                Console.WriteLine("Employee Not found...!!");
            }
            Console.ReadKey();
        }
        }
    }

