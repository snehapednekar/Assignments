﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace Assignment7_3
{
    [Serializable()]
    class Employee
            {
                protected int EmpNo { get; set; }
                protected string EmpName { get; set; }
                protected double Salary { get; set; }
                protected double HRA { get; set; }
                protected double TA { get; set; }
                protected double DA { get; set; }
                protected double PF { get; set; }
                protected double TDS { get; set; }
                protected double NetSalary { get; set; }
                protected double GrossSalary { get; set; }

       
        public Employee(int EmpN, string Empname, double sal)
                {
                    this.EmpNo = EmpN;
                    this.EmpName = Empname;
                    this.Salary = sal;

                    if (Salary < 5000)
                    {

                        HRA = (Salary * 10) / 100;
                        TA = (Salary * 5) / 100;
                        DA = (Salary * 15) / 100;
                        GrossSalary = (Salary + HRA + TA + DA);
                        Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

                    }
                    else if ((Salary > 5000) && (Salary < 10000))
                    {

                        HRA = (Salary * 15) / 100;
                        TA = (Salary * 10) / 100;
                        DA = (Salary * 20) / 100;
                        GrossSalary = (Salary + HRA + TA + DA);
                        Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

                    }
                    else if ((Salary > 10000) && (Salary < 15000))
                    {

                        HRA = (Salary * 20) / 100;
                        TA = (Salary * 15) / 100;
                        DA = (Salary * 25) / 100;
                        GrossSalary = (Salary + HRA + TA + DA);
                        Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

                    }
                    else if ((Salary > 15000) && (Salary < 20000))
                    {

                        HRA = (Salary * 25) / 100;
                        TA = (Salary * 20) / 100;
                        DA = (Salary * 30) / 100;
                        GrossSalary = (Salary + HRA + TA + DA);
                        Console.Write("\n Gross Salary :{0}\n ", +GrossSalary);

                    }
                    else
                    {
                        HRA = (Salary * 30) / 100;
                        TA = (Salary * 25) / 100;
                        DA = (Salary * 35) / 100;
                        GrossSalary = (Salary + HRA + TA + DA);
                        Console.Write("Gross Salary :{0}\n ", +GrossSalary);

                    }
                }

                public virtual void CalculateSalary()
                {
                    PF = (GrossSalary * 10) / 100;
                    TDS = (GrossSalary * 18) / 100;
                    NetSalary = GrossSalary - (PF + TDS);
                    Console.Write("Net Salary :{0}\n ", +NetSalary);
                }

                public virtual void GSal()
                {
                    Console.WriteLine(GrossSalary);
                }
            }
    [Serializable()]
    class Manager : Employee
            {
                private double PetrolAllowance { get; set; }
                private double FoodAllowance { get; set; }
                private double OtherAllowance { get; set; }

                public Manager(int EmpN, string Empname, double sal) : base(EmpN, Empname, sal)
                {
                    PetrolAllowance = (Salary * 8) / 100;
                    FoodAllowance = (Salary * 13) / 100;
                    OtherAllowance = (Salary * 3) / 100;
                }
                public override void GSal()
                {
                    GrossSalary = (GrossSalary + PetrolAllowance + FoodAllowance + OtherAllowance);

                }
                public override void CalculateSalary()
                {
                    NetSalary = GrossSalary - (PF + TDS);
                    Console.Write("Net Salary :{0}\n ", +NetSalary);
                }
            }
    [Serializable()]
    class MarketingExe : Employee
            {
                private double KilometerTravaled { get; set; }
                private double TourAllowance { get; set; }
                private double TelephoneAllowance { get; set; }

                public MarketingExe(int EmpN, string Empname, double sal) : base(EmpN, Empname, sal)
                {
                    KilometerTravaled = 100;
                    TourAllowance = 5 * KilometerTravaled;
                    TelephoneAllowance = 1000;

                }
                public override void GSal()
                {
                    GrossSalary = (GrossSalary + TourAllowance + TelephoneAllowance);

                }
                public override void CalculateSalary()
                {
                    NetSalary = GrossSalary - (PF + TDS);
                    Console.Write("Net Salary :{0}\n ", +NetSalary);
                }
            }
            class Program
            {
                static void Main(string[] args)
                {
            FileStream stream = new FileStream("E:\\sss.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            Console.WriteLine("Manager Details:\n");
                    Manager m = new Manager(1, "sn", 5000);
            formatter.Serialize(stream, m);

            // Delegate dm = new Delegate(m.GSal);
            //dm += new Delegate(m.CalculateSalary);
            // dm();

            Console.WriteLine("\n\nMarketing Executive Details:\n");
                    MarketingExe m1 = new MarketingExe(2, "ok", 10000);
            formatter.Serialize(stream, m1);
            //  Delegate dm1 = new Delegate(m1.GSal);
            // dm1 += new Delegate(m1.CalculateSalary);
            // dm1();
            Console.ReadKey();

                }
            }

        }


   