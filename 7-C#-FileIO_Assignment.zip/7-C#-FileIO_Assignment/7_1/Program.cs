﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace AssignmentFile
{
    class Program
    {
        static void Main(string[] args)
        {
            String path = @"D:\cs";
            DirectoryInfo fl = new DirectoryInfo(path);
            fl.Create();
            {
                Console.WriteLine("Directory has been created");
            }

            // CreateSubdirectory Method  
            path = @"D:\cs";
             fl = new DirectoryInfo(path);
            DirectoryInfo dis = fl.CreateSubdirectory("hellotest.txt");
            {
                Console.WriteLine("Directory has been created");
            }

            // GetDirectories method  
            try
            {
                DirectoryInfo di1 = new DirectoryInfo(@"D:\cs");
                DirectoryInfo[] dir1 = di1.GetDirectories();
                Console.WriteLine("The number of directories containing is {0}.", dir1.Length);
            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            }

            // GetFiles method  
            DirectoryInfo di = new DirectoryInfo(@"D:\cs");
            DirectoryInfo[] dirs = di.GetDirectories();
            foreach (DirectoryInfo diNext in dirs)
            {
                Console.WriteLine("The number of files in {0} is {1}", diNext,
                diNext.GetFiles().Length);
                
            }
            Console.ReadKey();

        }
        
    }
    
 }
   