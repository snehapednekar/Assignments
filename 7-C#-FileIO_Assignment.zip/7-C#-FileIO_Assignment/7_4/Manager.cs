﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assignment7_4
{
    [Serializable]
    class Manager
    {

            public int ID;
            public String Name;
        public int Salary;
        static void Main(string[] args)
        {
            Manager obj = new Manager();
                obj.ID = 1;
                obj.Name = "Sneha";
            obj.Salary = 50000;

                IFormatter formatter = new BinaryFormatter();
                Stream stream = new FileStream(@"E:\ManEg.txt", FileMode.Create, FileAccess.Write);

                formatter.Serialize(stream, obj);
                stream.Close();

                stream = new FileStream(@"E:\ManEg.txt", FileMode.Open, FileAccess.Read);
                Manager objnew = (Manager)formatter.Deserialize(stream);

                Console.WriteLine(objnew.ID);
                Console.WriteLine(objnew.Name);
            Console.WriteLine(objnew.Salary);
                Console.ReadKey();
            }
        }
    }
